package EJ8;

import java.util.Set;
import java.util.TreeSet;

public class Profesor {
	
	String nrp;
	String nombre;
	String categoria;
	String area;
	
	public Departamento dirige;
	public Departamento pertenece;
	public Set<Grupo> ense�a = new TreeSet<Grupo>();

}
