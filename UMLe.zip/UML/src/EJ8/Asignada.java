package EJ8;

import java.util.Set;
import java.util.TreeSet;

public class Asignada {
	
	String dia;
	String hora;
	
	public Set<Grupo> grupo = new TreeSet<Grupo>();
	public Set<Aula> aula = new TreeSet<Aula>();

}