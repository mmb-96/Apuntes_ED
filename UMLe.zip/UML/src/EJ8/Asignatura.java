package EJ8;

import java.util.Set;
import java.util.TreeSet;

public class Asignatura {
	
	String id;
	String nombre;
	String creditos;
	String caracter;
	String curso;
	
	public Set<Grupo> impartida = new TreeSet<Grupo>();

}
