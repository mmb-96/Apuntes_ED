package EJ8;

public class Aula {
	
	String id;
	String capacidad;

}