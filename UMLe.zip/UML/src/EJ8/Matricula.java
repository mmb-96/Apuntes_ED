package EJ8;

import java.util.Set;
import java.util.TreeSet;

public class Matricula {
	
	String calificacion;
	
	public Set<Alumno> alumno = new TreeSet<Alumno>();
	public Grupo grupo;

}