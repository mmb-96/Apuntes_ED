package EJ8;

import java.util.Set;
import java.util.TreeSet;

public class Grupo {
	
	String id;
	String tipo;
	
	public Set<Profesor> ense�a = new TreeSet<Profesor>();
	public Asignatura imparte;
	public Asignada asignado;
	public Matricula matricula;

}