package EJ8;

import java.util.Set;
import java.util.TreeSet;

public class Departamento {
	
	String id;
	String nombre;
	
	public Profesor dirige;
	public Set<Profesor> pertenece = new TreeSet<Profesor>();
}
