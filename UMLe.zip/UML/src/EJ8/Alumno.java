package EJ8;

import java.util.Set;
import java.util.TreeSet;

public class Alumno {
	
	String dni;
	String nombre;
	String direccion;
	String beca;
	
	public Set<Matricula> matricula = new TreeSet<Matricula>();

}