package EJ8;

public class Alumno {
	
	String dni;
	String nombre;
	String direccion;
	String beca;

}