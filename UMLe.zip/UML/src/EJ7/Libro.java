package EJ7;

import java.util.Set;
import java.util.TreeSet;

public class Libro {
	
	private String isbn;
	private String titulo;
	private String editorial;
	
	public Set<Comentario> comentario = new TreeSet<Comentario>();
	public Set<Autor> autor = new TreeSet<Autor>();
	public Set<Tema> tema = new TreeSet<Tema>();

}
