package EJ7;

import java.util.Set;
import java.util.TreeSet;

public class Usuario {
	
	private String nombre;
	private String clave;
	
	public Set<Comentario> comentario = new TreeSet<Comentario>();

}
