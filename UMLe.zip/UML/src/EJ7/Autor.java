package EJ7;

import java.util.Set;
import java.util.TreeSet;

public class Autor {
	
	private String nombre;
	
	public Set<Libro> libro = new TreeSet<Libro>();

}
