package EJ7;

import java.util.Set;
import java.util.TreeSet;

public class Tema {

	private String descipcion;
	
	public Set<Libro> libro = new TreeSet<Libro>();
	
	private Set<Tema> superTema = new TreeSet<Tema>();
	private Set<Tema> sub = new TreeSet<Tema>();
}
