package EJ7;

public class Comentario {
	
	private String fecha;
	private String texto;
	private String puntuacion;
	
	public Usuario usuario;
	public Libro libro;
}
