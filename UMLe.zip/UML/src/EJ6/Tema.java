package EJ6;

import java.util.Set;
import java.util.TreeSet;

public class Tema {
	private String id;
	private String descripcion;
	
	public Set<Tema> superTeema = new TreeSet<Tema>();
}
