package EJ6;

public class Libro {
	
	private String isbn;
	private String titulo;
	private String autor;
	private String editorial;
	private String ano;
	
	public Tema tema;
}
