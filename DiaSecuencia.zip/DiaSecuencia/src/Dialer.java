
public class Dialer {
	
	private Display display;
	private Speaker speaker;
	
	
	public void digit(String code) {
			display.displayDigit(code);
			speaker.emitTone(code);
	}
	

}
