
public class Speaker {

	public void emitTone(String code) {
		
	}
}
