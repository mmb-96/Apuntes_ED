
public class Display {

	public void displayDigit(String code) {
	}
	
	public void inUser() {
	}
}
