
public class Button {

	private Dialer dialer;
	
	public void init(String code) {
		for (int i = 0; i < 9; i++) {
			dialer.digit(code);
		}
	}
	
	public void send() {
	}
	
}
