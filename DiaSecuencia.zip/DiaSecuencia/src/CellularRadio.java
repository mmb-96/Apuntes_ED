
public class CellularRadio {

	
	public void connect(String pro) {
		
	}

}
